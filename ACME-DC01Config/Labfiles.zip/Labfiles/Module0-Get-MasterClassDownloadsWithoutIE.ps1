﻿param (
    [Parameter(Mandatory=$true)]
    [ValidateSet("AADConnect", "IDFix", "AADConnectHealth","EWSManagedAPI","O365PPDepTool","AzInfoProtection_UL")]
    [string]$Tool = "",
    $Destination = "C:\Temp2" 
)

if (-not (Test-Path -LiteralPath $Destination)) {
    
    try {
        New-Item -Path $Destination -ItemType Directory -ErrorAction Stop | Out-Null #-Force
    }
    catch {
        Write-Error -Message "Unable to create directory '$Destination'. Error was: $_" -ErrorAction Stop
    }
    "Successfully created directory '$Destination'."

}
else {
    "Directory already existed"
}

switch ($Tool) {
    'AADConnect' {
        $DLAddress = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=47594"
    }
    'AADConnectHealth' {
        $DLAddress = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=48261"
    }
    'IDFix' {
        $DLAddress = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=36832"
    }
    'EWSManagedAPI' {
        $DLAddress = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=42951"
    }
    'O365PPDepTool' {
        $DLAddress = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=49117"
    }
    'AzInfoProtection_UL' {
        $DLAddress = "https://www.microsoft.com/en-us/download/confirmation.aspx?id=53018"
    }
}
$File =  ((Invoke-WebRequest -Uri $DLAddress -UseBasicParsing).links | 
            Where-Object -Property href -Match -Value "msi$|exe$|docx$|bin$|zip$").href | Select-Object -Unique

Foreach ($dl in $File){
Start-BitsTransfer -Source $dl -Destination $Destination
}