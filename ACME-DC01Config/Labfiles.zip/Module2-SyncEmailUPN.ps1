﻿# Set correct upn on all users
$domain = get-adforest |select upnsuffixes -ExpandProperty upnsuffixes
$Users=Get-ADuser -Filter * -SearchBase "OU=Users,OU=ACME,DC=CORP,DC=ACME,DC=COM"

Foreach ($user in $users){
    $upn = "$($user.GivenName.ToLower()).$($user.Surname.ToLower())@$($domain)"
    Set-ADUser -EmailAddress:$upn -Identity:$User.DistinguishedName -Server:"acme-dc01.corp.acme.com" -UserPrincipalName:$upn
    }

# This line will trigger an error for the lab
Set-ADUser -Identity:abrall -Server:"acme-dc01.corp.acme.com" -UserPrincipalName:"åbramham,allenford@$($domain)"

# This will download and extract ID fix
Start-BitsTransfer https://download.microsoft.com/download/7/7/0/770A304A-1C2A-4EBE-8BB8-E7EDA9904AF1/IdFix.zip -Destination C:\Users\sysadmin\Downloads
function Expand-ZIPFile($file, $destination)
 {
 $shell = new-object -com shell.application
 $zip = $shell.NameSpace($file)
 foreach($item in $zip.items())
 {
 $shell.Namespace($destination).copyhere($item)
 }
 }
 Expand-ZIPFile –File "C:\Users\sysadmin\Downloads\IdFix.zip" –Destination "C:\Users\sysadmin\Downloads"
 Remove-Item -Path C:\Users\sysadmin\Downloads\IdFix.zip -Force