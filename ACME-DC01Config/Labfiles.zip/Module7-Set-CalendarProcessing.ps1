﻿#Connect to Azure Automation
$Credentials = Get-AutomationPSCredential -Name 'AzureAD Admin'
 
# Function: Connect to Exchange Online 
function Connect-ExchangeOnline {
    param (
        $Creds
    )
        Write-Output "Connecting to Exchange Online"
        Get-PSSession | Remove-PSSession       
        $Session = New-PSSession –ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $Creds -Authentication Basic -AllowRedirection
        $Commands = @("Get-MailboxFolderPermission","Set-MailboxFolderPermission","Set-Mailbox","Get-Mailbox","Set-CalendarProcessing","Add-DistributionGroupMember")
        Import-PSSession -Session $Session -DisableNameChecking:$true -AllowClobber:$true -CommandName $Commands | Out-Null
    }
 
# Connect to Exchange Online
Connect-ExchangeOnline -Creds $Credentials
 
# Set calendar processing on all new mailboxes
Get-Mailbox -RecipientTypeDetails RoomMailbox | Where-Object {$_.WhenCreated –ge ((Get-Date).Adddays(-1))} | Set-CalendarProcessing -DeleteSubject $false -AddOrganizerToSubject $false
Write-Output "Calenderprocessing set!"

 
# Close Session
Get-PSSession | Remove-PSSession
 
Write-Output "Script Completed!"