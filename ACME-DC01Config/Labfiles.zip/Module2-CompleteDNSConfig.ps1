﻿#This will add new domain to UPN suffixes in Active Directory
$DomainName = "labXXXXX.o365ready.com"
Get-ADForest | Set-ADForest -UPNSuffixes @{Add=$DomainName}

#This will add domain to Office 365. Requries you to be connected as global admin using connect-azuread
New-AzureADDomain -Name $DomainName -IsDefault $true
$verificationTXT = (Get-AzureADDomainVerificationDnsRecord -Name $DomainName | Where-Object {$_.RecordType -eq 'txt'}).text

#Connect to AzureRM with you credentials for Azure Subscription hosting DNS resourcegroup
Connect-AzureRmAccount

#Create DNS Zone in Azure
$ResourceGroup = "O365Labb"
$Zone = New-AzureRmDnsZone -Name $DomainName -ResourceGroupName $ResourceGroup

#Verify DNS
$Records = @()
$Records += New-AzureRmDnsRecordConfig -Value $verificationTXT
$RecordSet = New-AzureRmDnsRecordSet -Name "@" -RecordType TXT -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

    DO
    {
    Write-Host "Domain is not verified yet, please wait" -ForegroundColor Red
    Start-Sleep -Seconds 20
    Confirm-AzureADDomain -Name $DomainName


    $verificationstatus = (Get-AzureADDomain -Name $DomainName).isverfied
    } Until ($verificationstatus -eq $true)

Set-AzureADDomain -Name $DomainName -IsDefault $true
Write-Host "Domain is verified and set as default, DNS Config will continue" -ForegroundColor g

#Add records to DNS
$MX = $DomainName + ".mail.protection.outlook.com" -replace ".o365ready.com", "-o365ready-com"

$Records = @()
$Records += New-AzureRmDnsRecordConfig -Cname EnterpriseEnrollment-s.manage.microsoft.com
$RecordSet = New-AzureRmDnsRecordSet -Name "EnterpriseEnrollment" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzureRmDnsRecordConfig -Cname EnterpriseRegistration.windows.net
$RecordSet = New-AzureRmDnsRecordSet -Name "EnterpriseRegistration" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzureRmDnsRecordConfig -Cname clientconfig.microsoftonline-p.net
$RecordSet = New-AzureRmDnsRecordSet -Name "MSOID" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records


$Records = @()
$Records += New-AzureRmDnsRecordConfig -Cname autodiscover.outlook.com
$RecordSet = New-AzureRmDnsRecordSet -Name "autodiscover" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzureRmDnsRecordConfig -Cname sipdir.online.lync.com
$RecordSet = New-AzureRmDnsRecordSet -Name "sip" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzureRmDnsRecordConfig -Cname webdir.online.lync.com
$RecordSet = New-AzureRmDnsRecordSet -Name "lyncdiscover" -RecordType CNAME -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzureRmDnsRecordConfig -Exchange $MX -Preference 10
$RecordSet = New-AzureRmDnsRecordSet -Name "@" -RecordType MX -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzureRmDnsRecordConfig -Priority 100 -Weight 1 -Port 443 -Target sipdir.online.lync.com
$RecordSet = New-AzureRmDnsRecordSet -Name "_sip._tls" -RecordType SRV -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$Records = @()
$Records += New-AzureRmDnsRecordConfig -Priority 100 -Weight 1 -Port 5061 -Target sipfed.online.lync.com
$RecordSet = New-AzureRmDnsRecordSet -Name "_sipfederationtls._tcp" -RecordType SRV -ResourceGroupName $ResourceGroup -TTL 3600 -ZoneName $DomainName -DnsRecords $Records

$RecordSet = Get-AzureRmDnsRecordSet -Name "@" -RecordType TXT -ResourceGroupName $ResourceGroup -ZoneName $DomainName
Add-AzureRmDnsRecordConfig -RecordSet $RecordSet -Value "v=spf1 include:spf.protection.outlook.com -all"
Set-AzureRmDnsRecordSet -RecordSet $RecordSet
