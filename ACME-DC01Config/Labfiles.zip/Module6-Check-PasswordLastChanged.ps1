﻿param (
    [ValidateScript({Get-ADuser -Identity $_})]
    $UserName = ""
)
$ADuser = Get-ADUser -Identity $UserName
$Attribute = Get-ADReplicationAttributeMetadata -Object $aduser -Server ACME-DC01 -Properties unicodePwd
Write-Output "User: $UserName's password was last changed $($Attribute.LastOriginatingChangeTime)"