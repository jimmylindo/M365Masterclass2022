﻿$domain = get-adforest |select upnsuffixes -ExpandProperty upnsuffixes

Confirm-AzureADDomain -Name $domain
Set-AzureADDomain -Name $domain -IsDefault $true