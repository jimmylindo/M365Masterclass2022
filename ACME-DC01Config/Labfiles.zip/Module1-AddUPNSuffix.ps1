﻿$DomainName = "labXXXXX.o365ready.com"
Get-ADForest | Set-ADForest -UPNSuffixes @{Add=$DomainName}

