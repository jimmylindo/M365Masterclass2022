﻿$Users=Get-ADuser -Filter * -SearchBase "OU=Users,OU=ACME,DC=CORP,DC=ACME,DC=COM"

Foreach ($user in $users){
    $samaccountname = "$user.samaccountname"
    Set-ADUser -Identity:$User.DistinguishedName -Add @{mailNickname=$($user.samaccountname)} -Server:"acme-dc01.corp.acme.com"
    }