﻿[CmdletBinding(SupportsShouldProcess=$true)]
param ( 
    $UserPrincipalName
)
function Set-JDMsolMFASettings {
<#
.SYNOPSIS
    The function enables or disables Multi factor Authentication for Azure Active Directory users. It also has the ability to preselect the authentication methods for the users 
.PARAMETER UserPrincipalName
    UserPrincipalNames for the user(s) to manage.
.PARAMETER EnableMFA
    Turn on MFA for the user(s)
.PARAMETER DisableMFA
    Turn off MFA for the user(s)
.PARAMETER PreStageMethods
    Prestage the MFA methods the user should have. Allowed prestage methods are OneWaySMS (SMS OTP) and TwoWayVoiceMobile (Phone call)
.EXAMPLE 
    Get-MsolUser -UserPrincipalName aaron@365lab.net | Set-JDMsolMFASettings -EnableMFA 
    Enable MFA for one user
.EXAMPLE 
    Get-MsolUser -UserPrincipalName aaron@365lab.net | Set-JDMsolMFASettings -EnableMFA -PreStageMethods TwoWayVoiceMobile,OneWaySMS
    Enable MFA for one user, prestage the methods TwoWayVoiceMobile,OneWaySMS to avoid enrollment process at first logon.
.EXAMPLE 
    Get-MsolUser -DomainName tenant.onmicrosoft.com -All | Set-JDMsolMFASettings -EnableMFA 
    Enable MFA for all users in the tenant.onmicrosoft.com domain.
.EXAMPLE 
    Get-MsolUser -UserPrincipalName aaron@365lab.net | Set-JDMsolMFASettings -DisableMFA 
    Disable MFA for one user.
.NOTES
    Name: Set-JDMsolMFASettings
    Author   : Johan Dahlbom, johan[at]dahlbom.eu, @daltondhcp
    The script is provided “AS IS” with no guarantees, no warranties, and they confer no rights.    
#>
    [CmdletBinding(SupportsShouldProcess=$true)]
    param (
        [Parameter(Mandatory=$true,ValueFromPipeline=$true,ValueFromPipelineByPropertyName=$true)]
        [ValidateScript({Get-MsolUser -UserPrincipalName $_})]
        [string[]]$UserPrincipalName,
        [Parameter(ParameterSetName='EnableMFA')]
        [switch]$EnableMFA,
        [Parameter(ParameterSetName='EnableMFA')]
        [ValidateSet("OneWaySMS", "TwoWayVoiceMobile")]
        [string[]]$PreStageMethods,
        [Parameter(ParameterSetName='DisableMFA')]
        [switch]$DisableMFA
    )
    #Construct user HashTable
    $UserHt = @{}
    if ($DisableMFA) {
        #Create empty array to clear MFA settings
        $UserHt["StrongAuthenticationRequirements"] = @()
    } 
    if ($EnableMFA) {
        #Create MFA settings object
        $MFAsettings = New-Object -TypeName Microsoft.Online.Administration.StrongAuthenticationRequirement
        $MFAsettings.RelyingParty = "*"
        $MFAsettings.State = "Enforced"
        $UserHt["StrongAuthenticationRequirements"] = @($MFAsettings)
    }
    if ($PreStageMethods) {
        #Create objects for the prestaged methods in the order they were typed in
        $psm1 = New-Object -TypeName Microsoft.Online.Administration.StrongAuthenticationMethod
        $psm1.IsDefault = $true
        $psm1.MethodType = $PreStageMethods[0]
        $psm2 = New-Object -TypeName Microsoft.Online.Administration.StrongAuthenticationMethod
        $psm2.IsDefault = $false
        $psm2.MethodType = $PreStageMethods[1]
        $UserHt["StrongAuthenticationMethods"] = @($psm1, $psm2)
    }
    foreach ($user in $UserPrincipalName) {
        #Add the userprincipalname to the user hashtable
        $UserHt["UserPrincipalName"] = $user
        if ($PSCmdlet.ShouldProcess($UserPrincipalName,"Set")) {
            Set-MsolUser @UserHt
            Write-Verbose "$UserPrincipalName was enabled with multi factor authentication"
        }
    } 
}

Connect-MsolService 

Set-JDMsolMFASettings -UserPrincipalName $UserPrincipalName -EnableMFA 