﻿#Installera AZ modulen
Install-Module -Name Az -AllowClobber -Scope CurrentUser

#Anslut till Azure med powershell
Connect-AzAccount

#Updatera med ditt namn från student excelfilen
$domainname = "student.m365masterclass.space"

#Skapa DNS Zon i Azure
$dnszone = New-AzDnsZone -Name $domainname -ResourceGroupName M365Masterclass

#Skriv ut namnservrar för DNS
write-host "Update excel with these nameservers:" $dnszone.NameServers -ForegroundColor Green

#Lägg till UPN suffix i AD för domän
Get-ADForest | Set-ADForest -UPNSuffixes @{Add=$DomainName}

