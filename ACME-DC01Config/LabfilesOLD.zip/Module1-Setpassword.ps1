﻿$password = 'Ma$tercla$$'

get-aduser -filter * -SearchBase "OU=Users,OU=ACME,DC=corp,DC=acme,DC=com" |Set-ADAccountPassword -Reset -NewPassword (ConvertTo-SecureString -AsPlainText "$password" -Force)

